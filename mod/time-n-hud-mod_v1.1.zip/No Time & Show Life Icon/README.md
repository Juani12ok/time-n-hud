*\* (First of all, if you've paid for this, YOU'VE BEEN SCAMMED.)*

***

## Show Time & Life HUD Icons

# 1. How to use

As you may have noticed, there's no mod toggle to trigger the script which disables the time, nor show the lives. To enable those, you need to go to **SETTINGS > TWEAKS > ACCESSIBILITY**, and enable Infinite Lives, and/or Infinite Time, depending on the one you want to see.

There's two other Mod Toggles that works this way:

* **Life Number Flicker**: As it says, it makes the 0 number on the HUD flicker. (Needs to have **Infinite Lives** enabled, otherwise it won't work.)
* **Show Rings?**: This Toggle Makes the RINGS show or turn off like the TIME does.

***

# 2. Easter Eggs

There's a Chill Guy on the ```sprites``` Folder. Use it as you want, just don't erase the credit.

***

# 3. Bugs

1. It doesn't have compatibility with other Script Mods!
	* ***Solution:*** “Put this mod at the top of the other. If this doesnt work, try disabling the incompatible mod.”

2. TIME appears on bonus stages!
	* ***Solution:*** Wait. “I'm still trying to fix this one. I don't know why does this happen, but I'll eventually find why. Make sure the mod is updated!”

If there's another bug, say the issues on the Issues tab of the mod page (recommended for short explanations and/or not too important bugs), or try to DM me on GameBanana. You can also Comment on the mod page of GameBanana (recommended).

***

# 4. Q&A

1. Why Sonic, Tails and Knuckles have different names? Do the names mean something?

***Answer***: “1) Because you enabled the Custom Sprites option (yada-yada). 2) No. The names don't have any meaning. I just used them because those were the first names that came first on my head.”

2. Why? What is the point of it?

***Answer***: “The point of it is that if you don't want the Lives Icon to dissappear or you don't want to see the TIME when you have the Infinite Time option enabled, you can have a mod for it.”