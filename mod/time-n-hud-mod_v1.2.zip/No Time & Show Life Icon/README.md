*\* (First of all, if you've paid for this, YOU'VE BEEN SCAMMED.)*

***

## Show Time & Life HUD Icons

# 1. How to use

As you may have noticed, there's no mod toggle to trigger the script which disables the time, nor show the lives. To enable those, you need to go to **SETTINGS > TWEAKS > ACCESSIBILITY**, and enable Infinite Lives, and/or Infinite Time, depending on the one you want to see.

There's two other Mod Toggles that works this way:

* **Life Number Flicker**: As it says, it makes the 0 number on the HUD flicker. (Needs to have **Infinite Lives** enabled, otherwise it won't work.)
* **Show Rings?**: This Toggle Makes the RINGS show or turn off like the TIME does.
* **Infinite TIME will...**: This option will let you to choose between keep the TIME on hud when disabled, or erase it completely.

***

# 2. Easter Eggs

There's a Chill Guy on the ```sprites``` Folder. Use it as you want, just don't erase the credit.

***

# 3. Bugs

1. It doesn't have compatibility with other Script Mods!
	* ***Solution:*** “Put this mod at the top of the other. If this doesnt work, try disabling the incompatible mod.”

2. TIME appears on bonus stages!
	* ***Solution:*** “Make sure the mod is updated!”

If there's another bug, say the issues on the Issues tab of the mod page (recommended for long explanations and/or important bugs), or try to DM me on GameBanana. You can also Comment on the mod page of GameBanana (most recommended).

***

# 4. Q&A

1. Why Sonic, Tails and Knuckles have different names? Do the names mean something?

	* ***Answer***: “1) Because you enabled the Custom Sprites option (yada-yada). 2) No. The names don't have any meaning. I just used them because those were the first names that came first on my head.”

2. Why? What is the point of it?

	 * ***Answer***: “The point of it is that if you don't want the Lives Icon to dissappear or you don't want to see the TIME when you have the Infinite Time option enabled, you can have a mod for it.”

***

# 5. Changelog

**v1.1:**

[Addition] New toggle to erase the TIME from the HUD.
* This was part of a request made by [MeloSaxx](https://gamebanana.com/members/3951051), who gave the idea of remove the TIME from the HUD completely.

**v1.2:**

[Bug Fix] Fixed TIME showing up on Bonus Stages. Now it won't show up anymore.

[Bug Fix] Fixed the TIME off sprite showing up over TIME (This was notorious when you had another mod sprite active.)
* Well, I finally fixed these two bugs. Surprisingly, no one saw the second one, or told me; I found that one on my own when I had the [Someone & Knux's Better HUD](https://gamebanana.com/mods/544881) mod active. *Should I add something else?*"

***

# 6. Links

[![Show Lives and Disable TIME when Infinite](https://gamebanana.com/mods/embeddables/561987?type=large)](https://gamebanana.com/mods/561987) = Mod Page


[![Juani12ok's Member Logo](https://raw.githubusercontent.com/Juani12ok/Non-Trash-Stuff/refs/heads/discord-and-gb/Watermark%20GB%20Member.png)](https://gamebanana.com/members/2105843) = My Gamebanana Profile.